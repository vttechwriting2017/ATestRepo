#! /bin/bash
#
#  Last modified:  August 19, 2017
#
#  This script must be executed in a directory that contains the grading harness
#  tar file (CSetGrader.tar) posted on the course website; that tar file must
#  contain the files:
#
#     driver.c
#     CSet.h
#     gradeCSet.h
#     gradeCSet.o
#
#  The directory must also contain your completed CSet.c file; we recommend that
#  you name that file yourPID.c, using your VT email PID as the first part of the
#  file name.
#
#  Invocation:  ./gradeC01.sh <name of your CSet solution file>
#               e.g., ./gradeC01.sh wmcquain.c
#
#  A summary of the test results can be found in the file Summary.txt.  There
#  will be a separate log file for each test phase that was completed, and an
#  overall report, named PID.txt if you followed the suggested naming convention.
#
#  Alternate invocation:  ./gradeC01.sh -clean
#
#  This will remove the files created by an earlier run of the grading script;
#  it's useful if you just want to start with a pristine environment.
#
#  Name of grading package file
gradingTar="CSetGrader.tar"

#  Names for directories
buildDir="build"

#   Names for log files created by this script:
buildLog="buildLog.txt"
testLog="testLog.txt"

#   Name for the executable
exeName="driver"

#   Delimiter to separate sections of report file:
Separator="============================================================"

#   Set results file names
testLog="details.txt"
scoresLog="Summary.txt"

############################################# fn to check for tar file
#                 param1:  name of file to be checked
isTar() {

   mimeType=`file -b --mime-type $1`
   [[ $mimeType == "application/x-tar" ]]
}

##################################### fn to extract token from file name
#                 param1: (possibly fully-qualified) name of file
#  Note:  in production use, the first part of the file name will be the
#         student's PID
#
getPID() { 

   fname=$1
   # strip off any leading path info
   fname=${fname##*/}
   # extract first token of file name
   spid=${fname%%.*}
}
   
############################################################ Validate command line

# Verify number of parameters
   if [[ $# -ne 1 ]]; then
      echo "You must specify the name of your C file (or -clean)."
      exit 1
   fi
   
# See if user selected the cleaning option
  if [[ $1 == "-clean" ]]; then
     echo "Removing earlier test files..."
     rm -Rf *.txt $buildDir driver
     exit 0
  fi

# Verify presence of named file
   sourceFile="$1"
   if [ ! -e $sourceFile ]; then
      echo "The file $sourceFile does not exist."
      exit 2
   fi
   
############################################################ Check for grading package

   if [[ ! -e $gradingTar ]]; then
      echo "$gradingTar is not present"
      exit 3
   fi
   
   isTar $gradingTar
   if [[ $? -ne 0 ]]; then
      echo "$gradingTar does not appear to be a tar file"
      exit 4
   fi

############################################################ Get student's PID
   
   # Extract first token of C file name (student PID when we run this)
   getPID $sourceFile
   
   # Initiate header for grading log
   headerLog="header.txt"
   echo "Grading:  $1" > $headerLog
   echo -n "Time:     " >> $headerLog
   echo `date` >> $headerLog
   echo >> $headerLog
   
############################################################ Prepare for build
  
   # Create log file:
   echo "Executing gradeC1.sh..." > $buildLog
   echo >> $buildLog
   
   # Create build directory:
   echo "Creating build subdirectory" >> $buildLog
   echo >> $buildLog
   # Create build directory if needed; empty it if it already exists
   if [[ -d $buildDir ]]; then
      rm -Rf ./$buildDir/*
   else
      mkdir $buildDir
   fi
   
   # Unpack the test source files into the build directory
   echo "Unpacking test code into build directory:" >> $buildLog
   tar xf CSetGrader.tar -C ./$buildDir >> $buildLog
   
   # Copy student's C file to the build directory
   echo "Copying student source file to the build directory:" >> $buildLog
   cp $sourceFile ./$buildDir/CSet.c >> $buildLog
   echo >> $buildLog

   # Move to build directory
   cd ./$buildDir
   
############################################################ Build the test driver

   # build the driver; save output in build log
   echo "Compiling test code and submission" >> ../$buildLog
   gcc -o driver -std=c99 -Wall -ggdb3 driver.c CSet.c gradeCSet.o >> ../$buildLog 2>&1
   echo >> ../$buildLog

   # Verify existence of executable
   if [[ ! -e $exeName ]]; then
      echo "Build failed; the file $exeName does not exist" >> ../$buildLog
      echo $Separator >> ../$buildLog
      mv ../$buildLog ../$spid.txt
      exit 7
   fi
   if [[ ! -x $exeName ]]; then
      echo "Permissions error; the file $exeName is not executable" >> ../$buildLog
      echo $Separator >> ../$buildLog
      mv ../$buildLog ../$spid.txt
      exit 8
   fi

   echo "Build succeeded..." >> $buildLog
   
   # Move executable up to test directory and return there
   echo "Moving the executable $exeName to the test directory." >> $buildLog
   mv ./$exeName .. >> $buildLog
   cd .. >> $buildLog
   
   # Delimit this section of the report file:
   echo $Separator >> $buildLog

############################################################ Perform testing

   # Initiate test Log
   echo "Begin testing..." > $testLog
   echo >> $testLog
   
   # Set seed value
   # echo "1485876770" > Seed.txt
   
   # Execute the test code
   ./driver >> $testLog 2>&1
   
   # Accumulate individual test logs into details log
   detailsLog="details.txt"
   echo "Detailed results from tests:" >> $detailsLog
   echo >> $detailsLog
   cat InitLog.txt >> $detailsLog
   echo $Separator >> $detailsLog

   echo >> $detailsLog
   cat InsertLog.txt >> $detailsLog
   echo $Separator >> $detailsLog
   
   echo >> $detailsLog
   cat ContainsLog.txt >> $detailsLog
   echo $Separator >> $detailsLog
   
   echo >> $detailsLog
   cat RemoveLog.txt >> $detailsLog
   echo $Separator >> $detailsLog
   
   echo >> $detailsLog
   cat EqualsLog.txt >> $detailsLog
   echo $Separator >> $detailsLog
   
   echo >> $detailsLog
   cat SubsetLog.txt >> $detailsLog
   echo $Separator >> $detailsLog
   
   echo >> $detailsLog
   cat IntersectionLog.txt >> $detailsLog
   echo $Separator >> $detailsLog
   
   echo >> $detailsLog
   cat SymDifferenceLog.txt >> $detailsLog
   echo $Separator >> $detailsLog
   
   echo >> $detailsLog
   cat CopyLog.txt >> $detailsLog

############################################################ Run valgrind check

   #   full valgrind output is in $vgrindLog
   #   extracted counts are in $vgrindIssues
   vgrindLog="vgrindLog.txt"
   echo "Running valgrind test..." >> $vgrindLog
   vgrindSwitches=" --leak-check=full --show-leak-kinds=all --log-file=$vgrindLog --track-origins=yes -v"
   scoreResultsLog2="ScoresValgrind.txt"
   tmpVgrind="tmpVgrind.txt"
   valgrind $vgrindSwitches ./driver >> $tmpVgrind 2>&1
   if [[ -s $tmpVgrind ]]; then
      cat $tmpVgrind >> $vgrindLog
   fi
	   
   # accumulate valgrind error counts
   if [[ -e $vgrindLog ]]; then
      vgrindIssues="vgrind_issues.txt"
      echo "Valgrind issues:" > $vgrindIssues
      grep "in use at exit" $vgrindLog >> $vgrindIssues
      grep "total heap usage" $vgrindLog >> $vgrindIssues
      grep "definitely lost" $vgrindLog >> $vgrindIssues
      echo "Invalid reads: `grep -c "Invalid read" $vgrindLog`" >> $vgrindIssues
      echo "Invalid writes: `grep -c "Invalid write" $vgrindLog`" >> $vgrindIssues
      echo "Uses of uninitialized values: `grep -c "uninitialised" $vgrindLog`" >> $vgrindIssues
   else
      echo "Error running Valgrind test." >> $testLog
   fi
      
############################################################ File report
# complete summary file

   summaryLog="$spid.txt"
   
   # write header to summary log
   cat "$headerLog" > $summaryLog
   
   echo "Summary results from testing:" >> $summaryLog
   # write scores to summary file
   echo >> $summaryLog
   cat $scoresLog >> $summaryLog
   echo $Separator >> $summaryLog
   echo >> $summaryLog
   
   # write Valgrind summary into log
   echo "Summary of valgrind results:" >> $summaryLog
   echo >> $summaryLog
   cat $vgrindIssues >> $summaryLog
   echo $Separator >> $summaryLog
   
   # write testing details into summary
   cat $testLog >> $summaryLog
   echo $Separator >> $summaryLog
   
   # write Valgrind details into log
   echo "Details from valgrind check:" >> $summaryLog
   echo >> $summaryLog
   cat $vgrindLog >> $summaryLog
   echo $Separator >> $summaryLog

   # write build log into summary
   echo "Results from $buildLog" >> $summaryLog
   cat $buildLog >> $summaryLog
   echo >> $summaryLog

exit 0
